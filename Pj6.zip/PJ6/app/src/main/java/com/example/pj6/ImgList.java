package com.example.pj6;

import java.util.ArrayList;

public class ImgList
{
    private static volatile ImgList instance = null;

    protected ArrayList<String> IMG_LIST;

    private ImgList()
    {
        IMG_LIST = new ArrayList<>();
    }

    public static ImgList getInstance()
    {
        if (instance == null) {
            synchronized(ImgList.class)
            {
                if (instance == null) {
                    instance = new ImgList();
                }
            }
        }

        return instance;
    }

    public ArrayList<String> getIMG_LIST()
    {
        return IMG_LIST;
    }

}
