package com.example.pj6;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.StrictMode;
import android.util.Log;
import android.widget.ImageView;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class ImgDownloader
{
    public static ImgList imgList = ImgList.getInstance();
    public static Map<String, Bitmap> bitmaps = new HashMap<>();

    public static void getWebsite(String websiteURL)
    {
//        String resString = "";
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        HttpClient httpclient = new DefaultHttpClient();
        HttpGet httpget = new HttpGet(websiteURL);

        try
        {
            HttpResponse response;
            response = httpclient.execute(httpget);
            HttpEntity entity = response.getEntity();
            InputStream in = entity.getContent();

            BufferedReader reader = new BufferedReader(new InputStreamReader(in, "windows-1251"), 8);
            //StringBuilder sb =  new StringBuilder();
            String line = null;

            String urltag = "<span class='url'>";
            String urlori = "";
            String new_dir = "images/largesize/";
            String finalurl = "";

            while((line = reader.readLine()) != null)
            {
                if(line.contains(urltag))
                {
                    //sb.append(line + "\n");
                    urlori = line.substring(urltag.length(), line.length()-10);

                    if(urlori.indexOf("details") != -1)
                    {
                        finalurl = urlori.substring(0, urlori.indexOf("details"));
                        finalurl = finalurl + new_dir + urlori.substring(urlori.indexOf("=")+1) + "_hires.jpg";

                        imgList.IMG_LIST.add(finalurl);

                        Log.i("HTTP URL to Download:", finalurl );

                    }

                }

            }

            in.close();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }



    // AsyncTask to load weather condition icons in a separate thread
    protected static class LoadImageTask extends AsyncTask<String, Void, Bitmap>
    {
        private ImageView imageView; // displays the thumbnail

        // store ImageView on which to set the downloaded Bitmap
        public LoadImageTask(ImageView imageView)
        {
            this.imageView = imageView;
        }

        // load image; params[0] is the String URL representing the image
        @Override
        protected Bitmap doInBackground(String... params)
        {
            Bitmap bitmap = null;
            HttpURLConnection connection = null;

            try
            {
                URL url = new URL(params[0]); // create URL for image

                // open an HttpURLConnection, get its InputStream
                // and download the image
                connection = (HttpURLConnection) url.openConnection();

                try (InputStream inputStream = connection.getInputStream())
                {
                    bitmap = BitmapFactory.decodeStream(inputStream);
                    bitmaps.put(params[0], bitmap); // cache for later use
                }
                catch (Exception e)
                {
                    e.printStackTrace();
                }
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
            finally
            {
                connection.disconnect(); // close the HttpURLConnection
            }

            return bitmap;
        }

        // set NASA image in list item
        @Override
        protected void onPostExecute(Bitmap bitmap)
        {
            imageView.setImageBitmap(Bitmap.createScaledBitmap(bitmap,200,200,false));
        }



    }
}
