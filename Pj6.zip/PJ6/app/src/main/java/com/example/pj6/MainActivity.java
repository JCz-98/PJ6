
//proyecto 6

//Jonathan Cazco ; Erick Ñauñay
// Referencias:
// https://www.youtube.com/watch?v=HFM0Wwv021k --> descargar src pagina web
// WeatherViewer App --> descarga multithread de bitmaps para imagenes y cache

package com.example.pj6;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class MainActivity extends AppCompatActivity
{


    public static ImgList imgList = ImgList.getInstance();
    public static Map<String, Bitmap> bitmaps = ImgDownloader.bitmaps;

    public Map<Integer,String> inUse_bitmaps = new HashMap<>();

    public List<ImageView> init_img = new ArrayList<>();

    public List<String> work_img = imgList.IMG_LIST;

    ImageView img1;
    ImageView img2;
    ImageView img3;
    ImageView img4;
    ImageView img5;
    ImageView img6;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        img1 = findViewById(R.id.img1);
        init_img.add(img1);
        img2 = findViewById(R.id.img2);
        init_img.add(img2);
        img3 = findViewById(R.id.img3);
        init_img.add(img3);
        img4 = findViewById(R.id.img4);
        init_img.add(img4);
        img5 = findViewById(R.id.img5);
        init_img.add(img5);
        img6 = findViewById(R.id.img6);
        init_img.add(img6);

        ImgDownloader.getWebsite("https://nasasearch.nasa.gov/search?affiliate=nasa&page=12&query=%2A.jpg&sort_by=&utf8=%E2%9C%93");

        for(int i=0; i < init_img.size(); i++)
        {
            ImageView imgSet = init_img.get(i);

            String imgurl = imgList.IMG_LIST.get(i);
            Log.i("INIT_URL:", imgurl );


            if (bitmaps.containsKey(imgList.IMG_LIST.get(i)))
            {
                imgSet.setImageBitmap(bitmaps.get(imgurl));
            }
            else
            {
                // download and display NASA image
                inUse_bitmaps.put(imgSet.getId(),imgurl);
                new ImgDownloader.LoadImageTask(imgSet).execute(imgurl);
            }

        }

    }

    public void changeImage(View view)
    {

        int view_id = view.getId();
        Random rint = new Random();
        int rand_index = rint.nextInt(work_img.size()-1);
        String new_url = null;

        new_url = work_img.get(rand_index);

        ImageView cur_img = findViewById(view_id);

        if(inUse_bitmaps.containsValue(new_url))
        {
            changeImage(view);
        }
        else
        {
            Log.i("OnCLICK:", new_url );
            inUse_bitmaps.remove(view_id);
            inUse_bitmaps.put(view_id, new_url);

            if (bitmaps.containsKey(new_url))
            {
                cur_img.setImageBitmap(bitmaps.get(new_url));
            }
            else
            {
                // download and display NASA image
                inUse_bitmaps.put(cur_img.getId(),new_url);
                new ImgDownloader.LoadImageTask(cur_img).execute(new_url);
            }


        }

    }
}
